#!/usr/bin/python
encrypted='REh5YzgxSU1ZQXVT'
print encrypted.decode('base64')
