#!/bin/bash



red=$'\e[1;31m'
grn=$'\e[1;32m'
end=$'\e[0m'
bold=$'\e[1m'
yellow=$'\e[1;33m'
blue=$'\e[1;34m'
normal=$'\e[0m'
bold=$(tput bold)
normal=$(tput sgr0)
magneta=$'\e[1;35m'
cyan=$'\e[1;36m'
gray=$'\e[1;90m'
darkgray=$'\e[1;30m'
white=$'\e[1;37m'


usage() {
	echo "USAGE: $0 [-d|h]"
	echo "	-d debug"
	echo "	-h help"
	exit 1
}

setup() {

   SOURCE_DIR=$(dirname $0)
   NOW=$(date +"%Y%m%dT%H%M")
   LOGFILE=$SOURCE_DIR/logs/
   mkdir -p $LOGFILE

   vm_inventory=$SOURCE_DIR/inventory
   vm_create=$SOURCE_DIR/create_vm.yml

}


while getopts dh option
do
 case "${option}"
 in
 d) debug=1;;
 h) usage ;;
 \?) usage ;;
 esac
done

if [ "$debug" == "1" ];then
	ansibleflags="$ansibleflags -vv"
fi
setup
exec > >(tee $LOGFILE/restore_${NOW}.log)
exec 2>&1

while :
do
  echo "*********************************************"
  echo  "${green}1) Build VMS From AMIS${green}${end}"
  echo "---------------------------------------------"
  echo "q) exit"
  echo "*********************************************"
  echo "Please enter a menu option and enter or enter q to exit."

 read INPUT_STRING
  echo "Option $INPUT_STRING selected"
  case $INPUT_STRING in



         1)
          ansible-playbook -i $vm_inventory $vm_create $ansibleflags
          ;;
         
          q)
            exit 
            ;;
           
  esac
  echo "================================="
done

   
